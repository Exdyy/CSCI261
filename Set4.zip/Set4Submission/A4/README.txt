I tried to do this several times and have now restarted the assignment 4 times, and have spent way too much time on it (like 15 hours split between my several attempts). I feel like I am writing worse code every time I try, I have a ton of other school work to do, and my brain is thoroughly fried. So here is my extremely broken attempt.

Thanks,
Nick Willis

***be gentle please